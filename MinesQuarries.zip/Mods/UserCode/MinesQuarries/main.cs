namespace Mineshafts
{
    public class Build
    {
        public static void Main()
        {
            // dotnet an arbitrary entrypoint so it builds the rest of the project
        }
    }
}
