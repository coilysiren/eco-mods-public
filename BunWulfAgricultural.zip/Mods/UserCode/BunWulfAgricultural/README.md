# BunWulfAgricultural

A mod that a suite of recipes for agriculture. The goal of these recipes is to increase the flexibility of the Farming Speciality and allow it to impact the economy in novel ways.

You can find the source code for this mod here: https://github.com/coilysiren/eco-mods-public/

## Installation

Unzip the archive into the server root directory (where the executable lives). This will place all the files in their place automatically.

## Recipes

### Biochar Charcoal Burning

Replicates more charcoal using some base charcoal and vegetables inside of a bakery oven or kiln. Creates oil as a valuable by product.

The recipe is 4 charcoal, 10 vegetables => 6 charcoal, 4 oil

### Compost Decomposition

TODO

### Rice Paper

TODO

### Shredded Crops

TODO
